#!/bin/bash
set -e

# Remedy Fonts - Build Script for Android 10+

echo "=========================================="
echo "Building Remedy Fonts (Android 10 compatible)"
echo "=========================================="

# Check if Java is available
if ! command -v java &> /dev/null; then
    echo "Installing Java..."
    apt-get update -qq
    apt-get install -y openjdk-11-jdk > /dev/null 2>&1
fi

export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which java))))
echo "✅ Java: $JAVA_HOME"

# Clean and build
echo "🔄 Cleaning previous builds..."
rm -rf app/build

echo "🔄 Building APK for Android 10..."
gradle clean assembleRelease --no-daemon 2>&1 | tail -20

if [ -f "app/build/outputs/apk/release/app-release-unsigned.apk" ]; then
    echo ""
    echo "=========================================="
    echo "✅ BUILD SUCCESSFUL!"
    echo "=========================================="
    echo "📦 APK: app/build/outputs/apk/release/app-release-unsigned.apk"
    
    # Sign APK if keystore exists
    if [ -f "remedy-keystore.jks" ]; then
        echo ""
        echo "🔐 Signing APK..."
        jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
            -keystore remedy-keystore.jks \
            -storepass remedy123 \
            -keypass remedy123 \
            app/build/outputs/apk/release/app-release-unsigned.apk \
            remedy_key 2>&1 | grep -E "(added|verified|Entry)" || true
        
        mv app/build/outputs/apk/release/app-release-unsigned.apk \
           app/build/outputs/apk/release/RemedyFonts-Android10.apk
        
        echo "✅ Signed APK: RemedyFonts-Android10.apk"
        ls -lh app/build/outputs/apk/release/RemedyFonts-Android10.apk
    fi
else
    echo "❌ BUILD FAILED"
    exit 1
fi
