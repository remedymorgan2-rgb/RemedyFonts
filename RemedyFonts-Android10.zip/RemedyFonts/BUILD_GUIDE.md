# Remedy Fonts - Build & Deployment Guide

## 📱 Project Overview
- **App Name:** Remedy Fonts
- **Package:** com.remedyfonts.app
- **Target SDK:** 34 (Android 14)
- **Min SDK:** 21 (Android 5.0)
- **Features:** 70+ fonts, Quotes, Love Letters, Floating Bubble, AdMob Ads

---

## 🏗️ PART 1: BUILD ON GITHUB CODESPACES (RECOMMENDED)

### Step 1: Open Your Repository in Codespaces
1. Go to: https://github.com/remedymorgan2-rgb/RemedyFonts
2. Click **Code** button → **Codespaces** tab
3. Click **Create codespace on main**
4. Wait 2-3 minutes for setup

### Step 2: Build the APK
In the Codespaces terminal:

```bash
# Make build script executable
chmod +x build-cloud.sh

# Run build script
./build-cloud.sh
```

**Output:** 
- Unsigned APK: `app/build/outputs/apk/release/app-release-unsigned.apk`
- Build time: ~5-10 minutes

---

## 🔐 PART 2: SIGN THE APK

### Option A: Using Keystore (RECOMMENDED)

**Your keystore is already in the project:**
```
remedy-keystore.jks (password: remedy123, alias: remedy_key)
```

**Automatic signing (in build script):**
```bash
KEYSTORE_PASSWORD=remedy123 KEYSTORE_ALIAS=remedy_key ./build-cloud.sh
```

**Or manual signing:**
```bash
jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
    -keystore remedy-keystore.jks \
    -storepass remedy123 \
    -keypass remedy123 \
    app/build/outputs/apk/release/app-release-unsigned.apk remedy_key

# Rename to signed APK
mv app/build/outputs/apk/release/app-release-unsigned.apk \
   app/build/outputs/apk/release/RemedyFonts-signed.apk
```

### Option B: Create New Keystore

```bash
keytool -genkey -v -keystore remedy-new.keystore \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -alias remedy_key \
    -dname "CN=Your Name, O=Your Company, C=US"

# Then sign with above method
```

---

## 📤 PART 3: PUBLISH TO HUAWEI APPGALLERY

### Prerequisites
- Huawei ID (register free at https://appgallery.huawei.com)
- Signed APK (from Part 2)
- App icon (512x512 PNG)
- Screenshots (at least 5)

### Step-by-Step

#### 1. Register as Developer
- Visit: https://appgallery.huawei.com
- Click **Developer** → **Sign Up**
- Verify email address
- Complete profile

#### 2. Create App Entry
- **My Apps** → **New App**
- **App Name:** Remedy Fonts
- **Default Language:** English
- **Category:** Utilities / Tools
- **Content Rating:** Teen (for quotes)
- Click **Create**

#### 3. Upload APK
- **Release Management** → **APK Management**
- Click **Upload New APK**
- Select: `RemedyFonts-signed.apk`
- Wait for verification (usually instant)

#### 4. Set App Information
- **App Icon:** 512x512 PNG
- **Description:**
```
Remedy Fonts - Transform your text with 70+ unique fonts!

Features:
✨ 70+ stylish fonts and text styles
💬 Beautiful quotes and love letters
🎯 Quick copy with floating bubble
🎨 Real-time text preview
📱 Simple, beautiful interface
⚡ Zero ads, blazingly fast

Perfect for:
- Creating unique messages
- Copying fancy text for social media
- Writing love notes
- Making your text stand out

No registration required. No permissions needed.
Completely free and open-source!
```

- **Privacy Policy:** (Required - see "Privacy Policy Template" below)
- **Screenshots:** Add at least 5 (use your app screenshots)

#### 5. Configure AdMob
**IMPORTANT:** Update your actual AdMob ID in AndroidManifest.xml

**Before publishing:**
1. Get your AdMob Application ID from Google AdMob
2. Update `AndroidManifest.xml`:
```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-xxxxxxxxxxxxxxxx~yyyyyyyyyy"/>
```
3. Rebuild & resign APK
4. Reupload to Huawei

#### 6. Set Pricing & Availability
- **Pricing:** Free
- **Regions:** Select all regions
- **Age Rating:** 13+ (Teen)

#### 7. Submit for Review
- Click **Submit for Review**
- Review takes 1-3 days
- You'll receive approval email

---

## 🛠️ TROUBLESHOOTING

### Build Fails with "ANDROID_SDK_ROOT not set"
**Solution:**
```bash
export ANDROID_SDK_ROOT=$ANDROID_HOME
export PATH=$ANDROID_SDK_ROOT/tools:$PATH
./gradlew assembleRelease
```

### "Gradle build timeout"
**Solution:**
- Increase Codespaces RAM: Settings → 4GB
- Or run locally on PC with full Android Studio

### "compileSdk 34 not found"
**Solution:**
```bash
./gradlew build --refresh-dependencies
```

### Huawei upload says "APK signature invalid"
**Solution:**
- Ensure signed with SHA256 (not SHA1)
- Check keystore password
- Verify with: `jarsigner -verify -certs RemedyFonts-signed.apk`

### AdMob ads don't show in app
**Solution:**
- Check AdMob Application ID in AndroidManifest.xml
- Use test IDs during development:
  - Banner: `ca-app-pub-3940256099942544/6300978111`
  - Interstitial: `ca-app-pub-3940256099942544/1033173712`
  - Rewarded: `ca-app-pub-3940256099942544/5224354917`

---

## 📋 PRIVACY POLICY TEMPLATE

Create `PRIVACY_POLICY.txt`:

```
PRIVACY POLICY
Remedy Fonts

Last Updated: [DATE]

This Privacy Policy explains how Remedy Fonts ("We", "Us", "Our", or "App") 
collects, uses, and protects your information.

1. INFORMATION WE COLLECT
   - We do NOT collect personal information
   - We do NOT require registration or login
   - The app is fully functional offline

2. AD NETWORKS
   - We use Google AdMob to serve ads
   - AdMob may collect anonymous analytics
   - See Google's Privacy Policy: https://policies.google.com/privacy

3. PERMISSIONS
   - INTERNET: Required for ads only
   - WRITE_EXTERNAL_STORAGE: To save text/images (Android 10 and below)

4. DATA RETENTION
   - We retain no personal data
   - Local preferences are stored only on your device
   - Clearing app cache removes all local data

5. CHILDREN'S PRIVACY
   - This app is not directed to children under 13
   - We do not knowingly collect data from children

6. CONTACT US
   Contact us at: [YOUR EMAIL]

7. CHANGES TO POLICY
   We may update this policy. Continued use means acceptance.
```

---

## 🚀 QUICK REFERENCE

| Task | Command |
|------|---------|
| Build unsigned APK | `./gradlew assembleRelease` |
| Build with cloud script | `./build-cloud.sh` |
| Sign APK | `jarsigner -sigalg SHA256withRSA -digestalg SHA-256 -keystore remedy-keystore.jks ...` |
| Verify APK signature | `jarsigner -verify -certs RemedyFonts-signed.apk` |
| Run tests | `./gradlew test` |
| Clean build | `./gradlew clean` |

---

## 📝 IMPORTANT NOTES

1. **Keystore Security:** Your `remedy-keystore.jks` is in the project. 
   - Keep it safe
   - Never commit to public repos
   - Back it up to cloud storage (Google Drive)

2. **AdMob ID:** The current ID is a test ID. 
   - Replace with your real AdMob ID before publishing
   - Test ad serving before submitting to Huawei

3. **Huawei vs Google Play:**
   - Huawei AppGallery: Free to upload, no review fees
   - Google Play: $25 one-time developer fee
   - Both require valid AdMob account for monetization

4. **Version Management:**
   - Update `versionCode` in `app/build.gradle` for each release
   - Update `versionName` for user-facing version (e.g., "1.0", "1.1")

---

## ✅ FINAL CHECKLIST BEFORE PUBLISHING

- [ ] APK builds without errors
- [ ] APK is signed with correct keystore
- [ ] AdMob Application ID updated
- [ ] Tested on Android device
- [ ] Privacy Policy written
- [ ] App icon is 512x512 PNG
- [ ] At least 5 screenshots ready
- [ ] App description complete
- [ ] Huawei developer account created
- [ ] All permissions justified

---

## 🎉 You're Ready!

Once your app is approved by Huawei, you'll see:
- Download link
- Analytics dashboard
- Ad revenue tracking (connected to AdMob)

Need help? Check the troubleshooting section above or contact support.
