#!/bin/bash
# Remedy Fonts - Cloud Build Script
# Use this for GitHub Codespaces or GitHub Actions

set -e

echo "=========================================="
echo "Remedy Fonts - Cloud Build Script"
echo "=========================================="

# Step 1: Set ANDROID_HOME
if [ -z "$ANDROID_HOME" ]; then
    echo "❌ ANDROID_HOME not set"
    echo "For GitHub Codespaces, this is auto-set."
    echo "For local use, set: export ANDROID_HOME=/path/to/android-sdk"
    exit 1
fi

echo "✅ ANDROID_HOME: $ANDROID_HOME"

# Step 2: Make gradlew executable
chmod +x ./gradlew
echo "✅ Gradle wrapper executable"

# Step 3: Clean previous builds
echo "🔄 Cleaning previous builds..."
./gradlew clean

# Step 4: Build release APK
echo "🔄 Building release APK..."
./gradlew assembleRelease

# Step 5: Check output
APK_PATH="app/build/outputs/apk/release/app-release-unsigned.apk"
if [ -f "$APK_PATH" ]; then
    APK_SIZE=$(du -h "$APK_PATH" | cut -f1)
    echo "✅ BUILD SUCCESSFUL!"
    echo "📦 APK Location: $APK_PATH"
    echo "📊 Size: $APK_SIZE"
    
    # Step 6: Optional - Sign APK (requires keystore)
    if [ -f "remedy-keystore.jks" ]; then
        echo ""
        echo "🔐 Signing APK..."
        KEYSTORE_PASSWORD="${KEYSTORE_PASSWORD:-remedy123}"
        KEYSTORE_ALIAS="${KEYSTORE_ALIAS:-remedy_key}"
        
        jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 \
            -keystore remedy-keystore.jks \
            -storepass "$KEYSTORE_PASSWORD" \
            -keypass "$KEYSTORE_PASSWORD" \
            "$APK_PATH" "$KEYSTORE_ALIAS"
        
        # Verify signature
        jarsigner -verify -verbose -certs "$APK_PATH"
        
        # Rename to signed APK
        mv "$APK_PATH" "app/build/outputs/apk/release/RemedyFonts-signed.apk"
        echo "✅ APK Signed: app/build/outputs/apk/release/RemedyFonts-signed.apk"
    else
        echo "⚠️  Keystore not found. APK is unsigned."
        echo "To sign, place remedy-keystore.jks in project root."
    fi
else
    echo "❌ BUILD FAILED - APK not found"
    exit 1
fi

echo ""
echo "=========================================="
echo "✅ BUILD COMPLETE!"
echo "=========================================="
